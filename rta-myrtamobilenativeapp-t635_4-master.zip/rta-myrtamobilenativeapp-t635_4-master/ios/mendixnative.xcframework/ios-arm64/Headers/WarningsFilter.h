//
//  Copyright (c) Mendix, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, WarningsFilter) {
    all,
    partial,
    none
};
extern NSString * const WarningsFilter_toString[];
